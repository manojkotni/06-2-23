package com.pluralsight.blog.data;
import org.springframework.data.jpa.repository.JpaRepository;


import com.pluralsight.blog.model.Post;

import org.springframework.stereotype.Component;



@Component
 public interface PostRepository extends JpaRepository<Post, Long> {
}